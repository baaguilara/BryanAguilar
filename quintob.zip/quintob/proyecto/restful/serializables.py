from rest_framework import serializers
from caja.models import Cliente,CajaAhorros,CuentaAhorros
from productos.models import Producto

class ClienteSerializable(serializers.ModelSerializer):
	class Meta:
		model=Cliente
		fields=('cedula','nombres','apellidos')

class CajaSerializable(serializers.ModelSerializer):
	class Meta:
		model=CajaAhorros
		fields=('siglas','nombre')

class CuentaSerializable(serializers.ModelSerializer):
	class Meta:
		model=CuentaAhorros
		fields=("idC",'numeroCuenta','saldo')

class ProductoSerializable(serializers.ModelSerializer):
	class Meta:
		model=Producto
		fields=("nombre",'precio','cantidad','marca','equipo')