from django.shortcuts import render
from caja.models import Cliente,CajaAhorros,CuentaAhorros
from productos.models import Producto
from rest_framework import viewsets
from .serializables import ClienteSerializable,CajaSerializable,CuentaSerializable,ProductoSerializable


class ClienteViewSet(viewsets.ModelViewSet):
	serializer_class=ClienteSerializable
	queryset=Cliente.objects.all()
	queryset.order_by('apellidos')

class CajaViewSet(viewsets.ModelViewSet):
	serializer_class=CajaSerializable
	queryset=CajaAhorros.objects.all()

class CuentaViewSet(viewsets.ModelViewSet):
	serializer_class=CuentaSerializable
	queryset=CuentaAhorros.objects.all()

class ProductoViewSet(viewsets.ModelViewSet):
	serializer_class=ProductoSerializable
	queryset=Producto.objects.exclude(cantidad=0).order_by('marca')


# Create your views here.
