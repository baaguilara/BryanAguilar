from django.shortcuts import render,redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Producto
from .forms import FormularioProducto,ModFormularioProducto


def listar(request):
	productos=Producto.objects.all().order_by("nombre")
	context={
	"Productos":productos,
	}
	return render(request,"listarPro.html",context)




def modificar(request):
	f=ModFormularioProducto(request.POST or None)
	prod=Producto.objects.get(nombre=request.GET['nombre'])
	f.fields['marca'].initial=prod.marca
	f.fields['precio'].initial=prod.precio
	f.fields['cantidad'].initial=prod.cantidad
	f.fields['equipo'].initial=prod.equipo

	if request.method=='POST':
		if f.is_valid():
			datos=f.cleaned_data
			prod.marca=datos.get("marca")
			prod.precio=datos.get("precio")
			prod.cantidad=datos.get("cantidad")
			prod.equipo=datos.get("equipo")
			prod.save()
			
			return redirect(listar)

	context={
	"Productos":prod,
	"f":f,
	}
	return render(request,"modificar.html",context)

def crear(request):
	f=FormularioProducto(request.POST or None)
	
	if request.method=="POST":
		if f.is_valid():
			datos=f.cleaned_data
			nom=datos.get("nombre")
			mar=datos.get("marca")
			equi=datos.get("equipo")
			cant=datos.get("cantidad")
			pre=datos.get("precio")
			obj=Producto.objects.create(nombre=nom,marca=mar,equipo=equi,cantidad=cant,precio=pre)
			

			if obj:
				producto=Producto.objects.all()
				context={
				"Productos":producto,
				}
				return redirect(listar)
			else:
				context={
				"Resultado":"Problema",
				"Mensaje":"EL CLIENTE NO PUDO SER REGISTRADO",
				"let":"Aceptar",
				"direc":".."
				}
				return render(request,"guardarPro.html",context)

	context={
		"form":f,
		"titulo":"Formulario Producto",
		"let":"GUARDAR",
		"direc":"/caja"
	}
	return render(request,"crearPro.html",context)

def seguridad(request):
	obj=Producto.objects.get(nombre=request.GET['nombre'])
	context={
	'Productos':obj,
	}
	return render(request,'eliminarPro.html',context)


def eliminar(request):
	obj=Producto.objects.get(nombre=request.GET['producto'])
	if obj.delete():
		messages.add_message(request,messages.SUCCESS,"SE HA ELIMINADO EL CLIENTE",fail_silently=True)
	else :
		messages.add_message(request,messages.ERROR,"NO SE HA ELIMINADO EL CLIENTE",fail_silently=True)

	return redirect(listar)

