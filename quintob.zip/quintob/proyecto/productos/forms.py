from django import forms
from .models import Producto

class FormularioProducto(forms.ModelForm):
	class Meta:
		model=Producto
		fields=["nombre",'equipo','cantidad','marca','precio'] #se mapea desde la clase contacto en el models.py


class ModFormularioProducto(forms.ModelForm):
	class Meta:
		model=Producto
		fields=['equipo','cantidad','marca','precio'] #se mapea desde la clase contacto en el models.py
