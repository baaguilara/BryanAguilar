from django.conf.urls import include, url
from django.contrib import admin

from . import views

urlpatterns = [
    url(r'^$', "productos.views.listar"),
    url(r'^crear/$', "productos.views.crear"),
    url(r'^modificar/$', "productos.views.modificar"),
    url(r'^seguridad/$', "productos.views.seguridad"),
    url(r'^eliminar/$', "productos.views.eliminar"),
]
