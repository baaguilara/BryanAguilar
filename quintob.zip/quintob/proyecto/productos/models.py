from __future__ import unicode_literals

from django.db import models

class Producto(models.Model):
	listaEquipo= (('uniforme','uniforme'),('instrumento','insrumento'),('cronometro','cronometro'),('balon','balon'),('pesas','pesas'))
	nombre=models.CharField(max_length=30,unique=True)
	precio=models.DecimalField(max_digits=5,decimal_places=2)
	equipo=models.CharField(max_length=30,choices=listaEquipo)
	marca=models.CharField(max_length=30)
	cantidad=models.IntegerField(default=0)

	def __str__(self):
		return self.nombre
