from django.contrib import admin
from .models import Producto
# Register your models here.

class AdminProducto(admin.ModelAdmin):
	list_display=["__str__",'marca','precio','equipo','cantidad']
	list_editable=["cantidad","precio","equipo"]
	list_filter=["equipo","marca"]
	search_fields=["__str__","marca"]
	class Meta:
		model=Producto

admin.site.register(Producto,AdminProducto)
