from django.conf.urls import include, url
from django.contrib import admin

from . import views

urlpatterns = [
    url(r'^$', "caja.views.listar"),
    url(r'^crear/$', "caja.views.crear"),
    url(r'^modificar/$', "caja.views.modificar"),
    url(r'^seguridad/$', "caja.views.seguridad"),
    url(r'^eliminar/$', "caja.views.eliminar"),
    url(r'^login/$', "caja.views.login"),
    url(r'^transaccion/$', "caja.views.transaccion"),
]
