from django.contrib import admin
from .models import CajaAhorros
from .models import Cliente
from .models import CuentaAhorros
from .models import Transaccion

class AdminCajaAhorros(admin.ModelAdmin):
	list_display=["__str__","siglas","logo"]
	list_editable=["siglas"]
	list_filter=["siglas"]
	search_fields=["siglas"]
	class Meta:
		model=CajaAhorros


admin.site.register(CajaAhorros,AdminCajaAhorros)



class AdminCliente(admin.ModelAdmin):
	list_display=["__str__",'idCA','nombres','apellidos','correo','telefono','celular','direccion','genero','estadoCivil','fechaNacimiento']
	list_editable=["nombres","apellidos","correo","genero"]
	list_filter=["genero","apellidos","estadoCivil"]
	search_fields=["__str__"]
	class Meta:
		model=Cliente

admin.site.register(Cliente,AdminCliente)


class AdminCuentaAhorros(admin.ModelAdmin):
	list_display=[ "__int__",'idC','estado','fechaApertura','saldo']
	list_editable=["estado","saldo"]
	list_filter=["estado","fechaApertura","saldo"]
	search_fields=["__int__",'estado']
	class Meta:
		model=CuentaAhorros

admin.site.register(CuentaAhorros,AdminCuentaAhorros)


class AdminTransaccion(admin.ModelAdmin):
	list_display=["__str__",'fechaApertura','descripcion','tipo','valor']
	list_filter=["tipo","fechaApertura"]
	search_fields=["__str__",'tipo']
	class Meta:
		model=Transaccion

admin.site.register(Transaccion,AdminTransaccion)