from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login
from django.contrib.auth.decorators import login_required
from .models import Cliente
from .models import Transaccion
from .models import CajaAhorros
from .models import CuentaAhorros
from .forms import FormularioCliente
from .forms import FormularioClienteM
from .forms import FormularioTransaccion

def inicio(request):
	return render(request,"inicioC.html",{})


def login(request):
	f=AuthenticationForm(request.POST)
	context={
	"log":f,
	}
	if f.is_valid():
		usernam = request.POST['username']
		passwor = request.POST['password']
		user = authenticate(username=usernam, password=passwor)
		if user is not None:
			if user.is_active:
				login(username,password)
			else:
				return redirect(inicio)
		else:
			return redirect(inicio)

	return render(request,"login.html",context)


#@login_required(login_url="../caja/login/")
def listar(request):
	clientes=Cliente.objects.all()
	context={
	"clientes":clientes,
	}
	return render(request,"listar.html",context)


def cuentas(request):
	cuentas=CuentaAhorros.objects.get(idC=Cliente.objects.get(cedula=request.GET['cedula']))
	context={
	"cuentas":cuentas,
	}
	return render(request,"cuentas.html",context)


def transaccion(request):
	f=FormularioTransaccion(request.POST or None)
	clientes=CuentaAhorros.objects.get(numeroCuenta=request.GET['idCuenta'])
	if request.method=='POST':
		if f.is_valid():
			datos=f.cleaned_data
			if datos.get("tipo")=='d':
				clientes.saldo=clientes.saldo+datos.get("valor")
			else:
				clientes.saldo=clientes.saldo-datos.get("valor")
			clientes.save()
			
			
			return redirect(listar)

	context={
	"clientes":clientes,
	"f":f,
	}
	return render(request,"transaccion.html",context)




def modificar(request):
	f=FormularioClienteM(request.POST or None)
	clientes=Cliente.objects.get(cedula=request.GET['cedula'])
	f.fields['nombres'].initial=clientes.nombres
	f.fields['apellidos'].initial=clientes.apellidos
#	f.fields['cedula'].initial=clientes.cedula
#	f.fields['cedula'].disabled=True
	f.fields['correo'].initial=clientes.correo
	f.fields['telefono'].initial=clientes.telefono
	f.fields['celular'].initial=clientes.celular
	f.fields['direccion'].initial=clientes.direccion
	f.fields['estadoCivil'].initial=clientes.estadoCivil
	f.fields['genero'].initial=clientes.genero
	f.fields['fechaNacimiento'].initial=clientes.fechaNacimiento
	f.fields['fechaNacimiento'].disabled=True

	if request.method=='POST':
		if f.is_valid():
			datos=f.cleaned_data
			clientes.nombres=datos.get("nombres")
			clientes.apellidos=datos.get("apellidos")
			clientes.celular=datos.get("celular")
			clientes.telefono=datos.get("telefono")
			clientes.correo=datos.get("correo")
			clientes.direccion=datos.get("direccion")
			clientes.estadoCivil=datos.get("estadoCivil")
			clientes.genero=datos.get("genero")
			clientes.save()
			
			return redirect(listar)

	context={
	"clientes":clientes,
	"f":f,
	}
	return render(request,"modificar.html",context)

def crear(request):
	f=FormularioCliente(request.POST or None)
	
	if request.method=="POST":
		if f.is_valid():
			datos=f.cleaned_data
			nom=datos.get("nombres")
			ape=datos.get("apellidos")
			cedu=datos.get("cedula")
			corr=datos.get("correo")
			tele=datos.get("telefono")
			celu=datos.get("celular")
			dire=datos.get("direccion")
			esta=datos.get("estadoCivil")
			gene=datos.get("genero")
			fech=datos.get("fechaNacimiento")
			caja=CajaAhorros.objects.all()[0]
			obj=Cliente.objects.create(idCA=caja,nombres=nom,apellidos=ape,cedula=cedu,correo=corr,telefono=tele,celular=celu,direccion=dire,genero=gene,estadoCivil=esta,fechaNacimiento=fech)
			

			if obj:
				objetoCaja=CuentaAhorros.objects.create(idC=obj,numeroCuenta=cedu,estado=True,saldo=0)
				if objetoCaja:
					clientes=Cliente.objects.all()
					context={
					"clientes":clientes,
					}
					return redirect(listar)

			else:
				context={
				"Resultado":"Problema",
				"Mensaje":"EL CLIENTE NO PUDO SER REGISTRADO",
				"let":"Aceptar",
				"direc":".."
				}
				return render(request,"guardar.html",context)


	context={
		"form":f,
		"titulo":"Formulario Cliente",
		"let":"GUARDAR",
		"direc":"/caja"
	}
	return render(request,"crear.html",context)

def seguridad(request):
	obj=Cliente.objects.get(cedula=request.GET['cedula'])
	context={
	'cliente':obj,
	}
	return render(request,'eliminar.html',context)


def eliminar(request):
	obj=Cliente.objects.get(cedula=request.GET['cedula'])
	if obj.delete():
		messages.add_message(request,messages.SUCCESS,"SE HA ELIMINADO EL CLIENTE",fail_silently=True)
	else :
		messages.add_message(request,messages.ERROR,"NO SE HA ELIMINADO EL CLIENTE",fail_silently=True)

	return redirect(listar)

