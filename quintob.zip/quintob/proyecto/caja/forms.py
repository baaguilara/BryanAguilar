from django import forms
from .models import Cliente
from .models import Transaccion

class FormularioCliente(forms.ModelForm):
	class Meta:
		model=Cliente
		fields=["nombres",'apellidos','cedula','correo','telefono','celular','direccion','genero','estadoCivil','fechaNacimiento'] #se mapea desde la clase contacto en el models.py


class FormularioClienteM(forms.ModelForm):
	class Meta:
		model=Cliente
		fields=["nombres",'apellidos','correo','telefono','celular','direccion','genero','estadoCivil','fechaNacimiento'] #se mapea desde la clase contacto en el models.py


class FormularioTransaccion(forms.ModelForm):
	class Meta:
		model=Transaccion
		fields=["descripcion","tipo","valor"]
