from django.shortcuts import render
from .forms import Formulario
from .forms import FormularioModelo
from .models import Contacto

def inicio(request):
	f=FormularioModelo(request.POST or None)
	context={
		"form":f,
		"titulo":"Mi primer formulario",
		"let":"GUARDAR",
	}
	if f.is_valid():
		datos=f.cleaned_data
		n=datos.get("nombres")
		a=datos.get("apellidos")
		c=datos.get("cedula")
		e=datos.get("edad")
		em=datos.get("email")
		obj=Contacto.objects.create(nombres=n,apellidos=a,edad=e,cedula=c,email=em)
		context={
		"titulo":"CONTACTO AGREGADO",
		"let":"Aceptar",
		}
	#sumbit == TRUE
	#submit == FALSE --- no se realizan cambios en la bd
	return render(request,"inicio.html",context)

def caratula(request):
	return render(request,"caratula.html",{})

def presentacion(request):
	return render(request,"presentacion.html",{})