from django.contrib import admin
from .models import Contacto

class AdminContacto(admin.ModelAdmin):
	list_display=["__str__","nombres","apellidos","email", "edad"]
	list_editable=["nombres","apellidos"]
	list_filter=["email","cedula"]
	search_fields=["nombres","cedula"]
	class Meta:
		model=Contacto


admin.site.register(Contacto,AdminContacto)

