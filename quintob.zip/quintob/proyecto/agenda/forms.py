from django import forms
from .models import Contacto

class Formulario(forms.Form):
	nombres=forms.CharField(max_length=30)
	apellidos=forms.CharField(max_length=30)
	cedula=forms.CharField(max_length=10)
	edad=forms.IntegerField()
	email=forms.EmailField()

class FormularioModelo(forms.ModelForm):
	class Meta:
		model=Contacto
		fields=["nombres",'apellidos','cedula','edad','email'] #se mapea desde la clase contacto en el models.py
