var app=angular.module("app",["ngResource"]);

//se define el controlador
app.controller("controlador",function ($scope,datos){
	$scope.nombres='Lol';
	$scope.lista=datos.get();
	$scope.total=0;
	$scope.esconder=true;

$scope.ordenar=function(tipo){
		$scope.ordenado=tipo;
	};

$scope.suma=function(subtotal){
		$scope.total=$scope.total+subtotal;
	};

$scope.cancelar=function(subtotal){
		$scope.total=$scope.total-subtotal;
	};

$scope.comprar=function(){
		alert("USTED REALIZO LA COMPRA CON EXITO, EL VALOR TOTAL A PAGAR ES DE:"+$scope.total);
	};

}
);

//se define el factory de donde se extraeran los datos

app.factory("datos",['$resource',
	function($resource){
		return $resource("http://127.0.0.1:8000/prod/",{},{get:{method:'GET',params:{},isArray:true}});
	}
	]);